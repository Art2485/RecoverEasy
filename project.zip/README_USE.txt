RecoverEasy minimal Android project (no-wrapper).

Use with GitHub Actions workflow that runs Gradle 8.9 directly, e.g.:

.github/workflows/build-zip-apk.yml
-----------------------------------
name: Build APK from ZIP
on: { workflow_dispatch: {}, push: { paths: ['project.zip', '.github/workflows/build-zip-apk.yml'] } }
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - uses: android-actions/setup-android@v3
        with:
          packages: |
            platforms;android-34
            build-tools;34.0.0
            platform-tools
      - name: Unzip
        run: |
          rm -rf src && mkdir -p src
          unzip -q project.zip -d src
      - name: Build with Gradle 8.9 (no wrapper)
        uses: gradle/gradle-build-action@v3
        with:
          gradle-version: 8.9
          build-root-directory: src
          arguments: :app:assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: apk
          path: src/app/build/outputs/apk/debug/*.apk
-----------------------------------

Zip structure expectation when you re-zip your own project:
  - settings.gradle(.kts), build.gradle(.kts) at root
  - app/ module with AndroidManifest.xml and res/
  - (No need for gradlew using this workflow)
