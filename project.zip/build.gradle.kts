// Root build file intentionally minimal.
